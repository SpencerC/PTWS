package com.ptws.product;
import com.ptws.ProductFeed;

public class Bag extends ProductFeed {

}
